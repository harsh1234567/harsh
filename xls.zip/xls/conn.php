 <?php
 // error_reporting(1);//CREATE CONN, INCLUDE FUNXML.PHP
date_default_timezone_set("Asia/Kolkata");
$servername = "localhost";
$username = "root";//"sanjayw";
$password = "";//"dhb382";
//$dbname = "xml_file_insert";
$dbname = "xml_file_insert";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

?>