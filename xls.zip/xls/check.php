<form action="a.php">
        <input type="file" name="txtFile" id="eskal"  /></br>
<input type="submit" name="Import" value="Update Database" /> </b>